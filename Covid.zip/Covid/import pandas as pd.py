import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Check if required columns exist
required_columns = ['date', 'location', 'total_cases', 'new_cases', 'total_deaths', 'new_deaths', 'total_vaccinations']
missing_columns = [col for col in required_columns if col not in df.columns]

if missing_columns:
    print(f"Missing columns in dataset: {missing_columns}")
else:
    # Proceed with the analysis
    df['date'] = pd.to_datetime(df['date'])