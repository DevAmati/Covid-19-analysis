# Import required libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the COVID-19 dataset
# Provide the correct path to the dataset
df = pd.read_csv('c:/Users/DEATHSTROKE/Desktop/pythonassignments/Covid/owid-covid-data.csv')

# Check if required columns exist
required_columns = ['date', 'location', 'total_cases', 'new_cases', 'total_deaths', 'new_deaths', 'total_vaccinations']
missing_columns = [col for col in required_columns if col not in df.columns]

if missing_columns:
    print(f"Missing columns in dataset: {missing_columns}")
else:
    # Convert date column to datetime
    df['date'] = pd.to_datetime(df['date'])

    # Select specific countries for analysis
    countries_of_interest = ['United States', 'India', 'Brazil', 'United Kingdom', 'Germany']
    df_filtered = df[df['location'].isin(countries_of_interest)]

    # Handle missing values
    numeric_columns = ['total_cases', 'new_cases', 'total_deaths', 'new_deaths', 'total_vaccinations']
    df_filtered[numeric_columns] = df_filtered[numeric_columns].fillna(method='ffill')

    # Plot total cases over time for selected countries
    plt.figure(figsize=(12, 6))
    for country in countries_of_interest:
        country_data = df_filtered[df_filtered['location'] == country]
        plt.plot(country_data['date'], country_data['total_cases'], label=country)

    plt.title('Total COVID-19 Cases by Country', fontsize=15)
    plt.xlabel('Date', fontsize=12)
    plt.ylabel('Total Cases', fontsize=12)
    plt.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()